#ifndef STACK_USER2
#define STACK_USER2

#include <iostream>
#include "stackUser.cpp"
using namespace std;

void stackUser2()
{
  stackUser();
  cout << "Stack User2 called" << endl;
}

#endif // !STACK_USER2