#ifndef MESSAGE_H
#define MESSAGE_H

class Message
{
public:
  void printMessage();
};

#endif // !MESSAGE_H
