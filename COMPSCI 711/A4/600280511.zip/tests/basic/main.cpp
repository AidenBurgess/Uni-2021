#include "message.h"
#include <cstdlib>

using namespace std;

int main()
{

  Message m;
  m.printMessage();

  return 0;
}