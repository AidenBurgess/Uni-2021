#include <iostream>
#include "message.h"
using namespace std;

void Message::printMessage()
{
  cout << "Hello rld!" << endl;
}