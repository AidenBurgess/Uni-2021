#include <iostream>
#include "message.h"
using namespace std;

void Message::printMessage()
{
  cout << "Hello world!" << endl;
}