#include <iostream>
#include "options.h"
using namespace std;

void Options::printOptions()
{
  cout << "Options:" << endl;
}