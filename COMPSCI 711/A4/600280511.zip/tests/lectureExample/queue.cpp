#include <iostream>
#include "queue.h"
using namespace std;

void Queue::createQueue()
{
  cout << "Enter the size of the queue: " << endl;
}