#include "options.h"
#include "simulator.h"
#include <cstdlib>

using namespace std;

int main()
{
  Options options;
  Simulator simulator;
  simulator.start();

  return 0;
}