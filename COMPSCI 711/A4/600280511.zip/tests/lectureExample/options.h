#ifndef OPTIONS_H
#define OPTIONS_H

class Options
{
public:
  void printOptions();
};

#endif // !OPTIONS_H
