#ifndef STACK_H
#define STACK_H

class Stack
{
public:
  void createStack();
};

#endif // !STACK_H
