#ifndef SIMULATOR_H
#define SIMULATOR_H

class Simulator
{
public:
  void start();
};

#endif // !SIMULATOR_H
