#include <iostream>
#include "stack.h"
using namespace std;

void Stack::createStack()
{
  cout << "Enter the size of the stack: " << endl;
}