#include "g.h"
using namespace std;

void g(){
	cout << "g" << endl;
}