#ifndef file_f
#define file_f
#include <iostream>
void f();
#endif