#include "f.h"
#include "g.h"

using namespace std;

int main()
{
	f();
	g();
	return 0;
}