#include "f.h"
using namespace std;

void f(){
	cout << "f" << endl;
}