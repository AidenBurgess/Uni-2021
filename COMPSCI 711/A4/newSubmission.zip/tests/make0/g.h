#ifndef file_g
#define file_g
#include <iostream>
void g();
#endif