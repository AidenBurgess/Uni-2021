#include <iostream>
#include "stackUser2.cpp"
using namespace std;

void stackUser3()
{
  stackUser2();
  cout << "Stack User3 called" << endl;
}
