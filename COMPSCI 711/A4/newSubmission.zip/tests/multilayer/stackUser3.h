#ifndef STACK_USER3
#define STACK_USER3

void stackUser3();

#endif // !STACK_USER3