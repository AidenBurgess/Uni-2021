#include <iostream>
#include "stackUser3.h"
using namespace std;

void stackUser()
{
  cout << "Stack User called" << endl;
}
