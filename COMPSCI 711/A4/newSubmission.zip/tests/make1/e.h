#ifndef file_e
#define file_e
#include <iostream>
void e();
#endif