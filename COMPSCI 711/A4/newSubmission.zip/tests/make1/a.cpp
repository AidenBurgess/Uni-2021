#include "b.h"
#include "c.h"
#include "d.h"
using namespace std;

int main()
{
	b();
	c();
	d();
	return 0;
}