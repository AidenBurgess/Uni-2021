#ifndef file_d
#define file_d
void d();
#endif