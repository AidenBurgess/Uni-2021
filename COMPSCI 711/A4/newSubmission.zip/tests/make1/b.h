#ifndef file_b
#define file_b
void b();
#endif