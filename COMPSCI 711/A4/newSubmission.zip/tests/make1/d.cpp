#include "e.h"
#include "f.h"
#include "g.h"
#include "d.h"
using namespace std;

void d(){
	e();
	f();
	g();
}