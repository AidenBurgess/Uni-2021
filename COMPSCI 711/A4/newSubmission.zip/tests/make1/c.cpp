#include "e.h"
#include "f.h"
#include "g.h"
#include "c.h"
using namespace std;

void c(){
	e();
	f();
	g();
}