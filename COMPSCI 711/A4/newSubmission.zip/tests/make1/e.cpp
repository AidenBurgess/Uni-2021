#include "e.h"
using namespace std;

void e(){
	cout << "e" << endl;
}