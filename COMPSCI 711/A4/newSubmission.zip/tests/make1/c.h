#ifndef file_c
#define file_c
void c();
#endif