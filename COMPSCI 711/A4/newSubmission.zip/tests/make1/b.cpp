#include "b.h"
#include "e.h"
#include "f.h"
#include "g.h"
using namespace std;

void b(){
	e();
	f();
	g();
}