#include "b.h"
using namespace std;

int main()
{
	b();
	return 0;
}