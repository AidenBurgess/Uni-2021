#include "e.h"
#include "f.h"
using namespace std;

void e(){
	f();
}