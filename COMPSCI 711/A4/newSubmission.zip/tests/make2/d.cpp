#include "e.h"
#include "d.h"
using namespace std;

void d(){
	e();
}