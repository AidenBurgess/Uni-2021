#include "d.h"
#include "c.h"
using namespace std;

void c(){
	d();
}