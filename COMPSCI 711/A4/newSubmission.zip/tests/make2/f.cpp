#include "f.h"
#include "g.h"
using namespace std;

void f(){
	g();
}