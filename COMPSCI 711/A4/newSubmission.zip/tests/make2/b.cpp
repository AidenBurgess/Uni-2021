#include "b.h"
#include "c.h"
using namespace std;

void b(){
	c();
}