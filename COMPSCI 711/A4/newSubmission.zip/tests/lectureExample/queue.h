#ifndef QUEUE_H
#define QUEUE_H

class Queue
{
public:
  void createQueue();
};

#endif // !QUEUE_H
