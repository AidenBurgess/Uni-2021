const auth0 = {
	audience: "http://localhost:3001/",
	// Replace issuer here
	issuer: "https://dev-exampleissuer.au.auth0.com/",
};

module.exports = {
	auth0,
};
