“All submitted work is my own.”

Signed: Aiden Burgess

