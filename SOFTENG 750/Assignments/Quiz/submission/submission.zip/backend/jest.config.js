module.exports = {
    testEnvironment: 'node',
    roots: [
        './src'
    ]
}