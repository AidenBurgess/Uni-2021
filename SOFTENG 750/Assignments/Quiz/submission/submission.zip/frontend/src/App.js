import PressedButton from "./components/PressedButton";

function App() {
	return (
		<>
			<PressedButton buttonId="default" />
		</>
	);
}

export default App;
